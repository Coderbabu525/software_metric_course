
import streamlit as st
import pandas as pd
import numpy as np
import json
import matplotlib.pyplot as plt

st.title("Defect Inflow Measurement and Forecasting System")

uploaded_file = st.file_uploader("Upload weekly defect data CSV", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)
else:
    df = pd.read_csv("defect_inflow_data.csv")

st.write("### Raw Data", df.head())

# Load configuration
with open("config.json") as f:
    config = json.load(f)

method = st.selectbox("Forecasting Method", ["naive", "moving_average", "ewma", "linear"], index=1)
window = st.slider("Window Size (for MA/EWMA)", 2, 10, config["window_size"])
horizon = st.slider("Forecast Weeks Ahead", 1, 6, config["forecast_weeks"])
alpha = st.slider("EWMA alpha", 0.1, 0.9, config["alpha"])

y = df["defects_reported"].values

# Forecast logic
if method == "naive":
    forecast = [y[-1]] * horizon
elif method == "moving_average":
    forecast = [np.mean(y[-window:])] * horizon
elif method == "ewma":
    s = y[0]
    for val in y[1:]:
        s = alpha * val + (1 - alpha) * s
    forecast = [s] * horizon
elif method == "linear":
    x = np.arange(len(y))
    coef = np.polyfit(x, y, 1)
    forecast = list(np.polyval(coef, np.arange(len(y), len(y)+horizon)))

future_weeks = pd.date_range(start=pd.to_datetime(df["week_start"]).iloc[-1] + pd.Timedelta(weeks=1),
                             periods=horizon, freq="W")
forecast_df = pd.DataFrame({"week_start": future_weeks.strftime("%Y-%m-%d"),
                            "forecast_defects": np.round(forecast).astype(int)})

st.write("### Forecast", forecast_df)

# Plot
fig, ax = plt.subplots()
ax.plot(df["week_start"], df["defects_reported"], label="Historical", marker="o")
ax.plot(forecast_df["week_start"], forecast_df["forecast_defects"], label="Forecast", marker="x")
plt.xticks(rotation=45)
plt.legend()
st.pyplot(fig)

# Derived indicators
total_defects = df["defects_reported"].sum()
avg_weekly = df["defects_reported"].mean()
max_weekly = df["defects_reported"].max()
st.write("### Indicators")
st.write(f"Total defects (year): {total_defects}")
st.write(f"Average weekly defects: {avg_weekly:.1f}")
st.write(f"Peak weekly defects: {max_weekly}")

# Save forecast result
forecast_df.to_csv("forecast_output.csv", index=False)
st.success("Forecast results saved as forecast_output.csv")
